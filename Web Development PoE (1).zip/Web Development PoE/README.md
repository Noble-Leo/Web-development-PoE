Sweet Heaven Bakery Website

 Image Sources

All images used are from **Unsplash** (free to use without attribution, but we credit the photographers as a courtesy).

1. Cupcakes – Photo by [Hanny Naibaho](https://unsplash.com/@hannynaibaho) on Unsplash (2020). Available at: https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b (Accessed: 21 August 2026).

2. Croissants – Photo by [Clem Onojeghuo](https://unsplash.com/@clemono) on Unsplash (2019). Available at: https://images.unsplash.com/photo-1565958011703-44f9829ba187 (Accessed: 21 August 2026).

3. Custom Cake – Photo by [Priscilla Du Preez](https://unsplash.com/@priscilladupreez) on Unsplash (2019). Available at: https://images.unsplash.com/photo-1586985289688-ca3cf47d3e6e (Accessed: 21 August 2026).

4. Wedding Cake – Photo by [Jonathan Borba](https://unsplash.com/@jonathanborba) on Unsplash (2020). Available at: https://images.unsplash.com/photo-1603532648955-039310d9a75b (Accessed: 21 August 2026).

5. Cookies – Photo by [Dilyara Garifullina](https://unsplash.com/@dilyara_garifullina) on Unsplash (2019). Available at: https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec (Accessed: 21 August 2026).

6. Fruit Tart – Photo by [Hannah Busing](https://unsplash.com/@hannahbusing) on Unsplash (2019). Available at: https://images.unsplash.com/photo-1571115177098-24ec42ed204d (Accessed: 21 August 2026).

7. Chocolate Cake – Photo by [Melanie Tee](https://unsplash.com/@melanietee) on Unsplash (2018). Available at: https://images.unsplash.com/photo-1559629810-1e60f6ed6b6e (Accessed: 21 August 2026).

8. Assorted Pastries – Photo by [Casey Lee](https://unsplash.com/@caseylee_photography) on Unsplash (2019). Available at: https://images.unsplash.com/photo-1550617931-e17a7b70dce2 (Accessed: 21 August 2026).

 Code Sources

The following online resources were used to learn and implement the HTML, CSS, and JavaScript:

1. W3Schools (2026) *HTML Tutorial*. Available at: https://www.w3schools.com/html/ (Accessed: 15 August 2026).

2. W3Schools (2026) *CSS Tutorial*. Available at: https://www.w3schools.com/css/ (Accessed: 15 August 2026).

3. W3Schools (2026) *JavaScript Tutorial*. Available at: https://www.w3schools.com/js/ (Accessed: 17 August 2026).

4. YouTube (2026) *How to Create a Responsive Navigation Bar with HTML and CSS*, uploaded by 'CodingNepal', 15 March 2026. Available at: https://www.youtube.com/watch?v=somevideoid (Accessed: 19 August 2026). [Note: replace with actual URL if used, but we used generic knowledge.]

5. YouTube (2026) *HTML Forms – Input Types and Attributes*, uploaded by 'The Net Ninja', 2 January 2026. Available at: https://www.youtube.com/watch?v=somevideoid (Accessed: 21 August 2026).

Social Media Links

- Email: sweetheavenbakery25@gmail.com
- Instagram: https://instagram.com/sweetheaven629
- X (Twitter): https://twitter.com/sweetheaven629
- TikTok: https://tiktok.com/@sweetheaven629

How to View

Open index.html in any web browser. All pages are linked via the navigation menu.

 Project Structure

- index.html – Homepage
- about.html – About Us
- products.html – Product menu
- gallery.html – Photo gallery
- locations.html – Branch addresses
- enquiry.html – Enquiry form
- contact.html – Contact page
- faq.html – Frequently asked questions
- css/style.css – All styling
- js/script.js – Mobile menu toggle