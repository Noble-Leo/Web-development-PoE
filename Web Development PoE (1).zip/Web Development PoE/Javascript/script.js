// Wait for the page to fully load before running this
document.addEventListener('DOMContentLoaded', function() {

    // Find the hamburger button and the navigation menu
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.querySelector('nav ul');

    // Only run this if both exist (so it doesn't break if something is missing)
    if (hamburger && navMenu) {
        
        // When the hamburger is clicked, toggle the 'open' class on the menu
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('open');
        });

        // Optional: Close the menu when a link is clicked (makes it feel smoother on mobile)
        const navLinks = navMenu.querySelectorAll('a');
        navLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                navMenu.classList.remove('open');
            });
        });

    }

});